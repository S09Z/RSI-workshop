#!/usr/bin/env bash
# Install the orchestrator / worker / advisor setup for the current user.
# Nothing is written inside any project. Safe to run more than once.
#
#   ./install.sh              install
#   ./install.sh --uninstall  remove the agents, hooks entries, and commands
set -euo pipefail

SRC="$(cd "$(dirname "$0")" && pwd)"
CLAUDE_HOME="${CLAUDE_HOME:-$HOME/.claude}"
BIN_DIR="${BIN_DIR:-$HOME/.local/bin}"
SETTINGS="$CLAUDE_HOME/settings.json"
MARK="log_event.py"   # used to recognise our hook entries when merging/removing

uninstall=false
[ "${1:-}" = "--uninstall" ] && uninstall=true

command -v python3 >/dev/null || { echo "python3 is required"; exit 1; }

mkdir -p "$CLAUDE_HOME/agents" "$CLAUDE_HOME/hooks" "$CLAUDE_HOME/agent-dashboard" "$BIN_DIR"

if $uninstall; then
  rm -f "$CLAUDE_HOME/agents/orchestrator.md" "$CLAUDE_HOME/agents/worker.md" "$CLAUDE_HOME/agents/advisor.md"
  rm -f "$CLAUDE_HOME/hooks/log_event.py"
  rm -f "$BIN_DIR/orch" "$BIN_DIR/orch-headless" "$BIN_DIR/orch-dashboard"
  echo "Removed agents, hook script and commands. Dashboard data kept in $CLAUDE_HOME/agent-dashboard."
else
  cp "$SRC/claude-home/agents/"*.md "$CLAUDE_HOME/agents/"
  cp "$SRC/claude-home/hooks/log_event.py" "$CLAUDE_HOME/hooks/log_event.py"
  cp "$SRC/claude-home/agent-dashboard/"* "$CLAUDE_HOME/agent-dashboard/"
  cp "$SRC/bin/orch" "$SRC/bin/orch-headless" "$SRC/bin/orch-dashboard" "$BIN_DIR/"
  chmod +x "$CLAUDE_HOME/hooks/log_event.py" "$BIN_DIR/orch" "$BIN_DIR/orch-headless" "$BIN_DIR/orch-dashboard"
fi

# Merge hook entries into ~/.claude/settings.json without touching other settings.
python3 - "$SETTINGS" "$SRC/claude-home/settings.hooks.json" "$uninstall" "$MARK" <<'PY'
import json, os, sys, shutil, time
settings_path, hooks_path, uninstall, mark = sys.argv[1], sys.argv[2], sys.argv[3] == "true", sys.argv[4]
data = {}
if os.path.exists(settings_path):
    with open(settings_path, encoding="utf-8") as f:
        raw = f.read().strip()
        data = json.loads(raw) if raw else {}
    shutil.copy(settings_path, settings_path + f".bak-{int(time.time())}")
ours = json.load(open(hooks_path, encoding="utf-8"))["hooks"]
hooks = data.setdefault("hooks", {})

def is_ours(group):
    return any(mark in (h.get("command") or "") for h in group.get("hooks", []))

for event in list(hooks.keys()):
    hooks[event] = [g for g in hooks[event] if not is_ours(g)]
    if not hooks[event]:
        del hooks[event]
if not uninstall:
    for event, groups in ours.items():
        hooks.setdefault(event, []).extend(groups)
if not hooks:
    data.pop("hooks", None)
os.makedirs(os.path.dirname(settings_path), exist_ok=True)
with open(settings_path, "w", encoding="utf-8") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
    f.write("\n")
print(("Removed" if uninstall else "Merged") + " hook entries in", settings_path)
PY

case ":$PATH:" in *":$BIN_DIR:"*) ;; *) echo "Note: add $BIN_DIR to your PATH";; esac
$uninstall || echo "Installed. Next: cd <project> && orch   |   orch-headless \"task\"   |   orch-dashboard"
