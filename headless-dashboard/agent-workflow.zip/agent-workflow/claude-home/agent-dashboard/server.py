#!/usr/bin/env python3
"""Agent workflow dashboard — no dependencies, Python 3.8+.

    python3 dashboard/server.py                  # http://localhost:8765
    python3 dashboard/server.py --port 9000 --log path/to/events.jsonl
    python3 dashboard/server.py --json           # print metrics once (headless / CI)

Reads ~/.claude/agent-dashboard/events.jsonl written by the global hook
(optionally) run results appended by orch-headless.
"""
import argparse
import json
import os
import re
import time
from collections import defaultdict
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
DEFAULT_LOG = os.path.join(os.path.expanduser("~"), ".claude", "agent-dashboard", "events.jsonl")

TASK_ID_RE = re.compile(r"\[\s*([A-Za-z]+-?\d+)\s*\]")
STATUS_RE = re.compile(r"STATUS:\s*(WORKS|DOES_NOT_WORK|BLOCKED)", re.I)
CONF_RE = re.compile(r"CONFIDENCE:\s*(high|medium|low)", re.I)
ATTEMPTS_RE = re.compile(r"ATTEMPTS:\s*(\d+)")
MAX_ADVISOR_ROUNDS = 2


def load_events(path, project=None):
    events = []
    if not os.path.exists(path):
        return events
    with open(path, encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                e = json.loads(line)
            except json.JSONDecodeError:
                continue
            if project and e.get("project") != project and e.get("event") != "run_result":
                continue
            events.append(e)
    events.sort(key=lambda e: e.get("ts", 0))
    return events


def task_key(desc):
    if not desc:
        return "untagged"
    m = TASK_ID_RE.search(desc)
    return m.group(1).upper() if m else desc.strip()[:60]


def compute(events, now=None):
    now = now or time.time()
    dispatches = {}          # tool_use_id -> dispatch record
    order = []
    tool_calls = defaultdict(int)
    tool_fail = defaultdict(int)
    tokens_by_agent = defaultdict(int)
    plan = {}                # planned tasks from TodoWrite / TaskCreate
    runs = []                # headless run results
    sessions = set()

    for e in events:
        ev, tool = e.get("event"), e.get("tool")
        if e.get("session_id"):
            sessions.add(e["session_id"])

        if ev == "run_result":
            runs.append(e)
            continue

        if tool in ("Task", "Agent") and ev == "PreToolUse":
            tid = e.get("tool_use_id") or f"anon-{len(order)}"
            d = {
                "id": tid,
                "agent": (e.get("subagent_type") or "unknown").lower(),
                "description": e.get("description") or "",
                "task": task_key(e.get("description")),
                "project": e.get("project") or "",
                "start": e["ts"],
                "end": None,
                "status": "RUNNING",
            }
            dispatches[tid] = d
            order.append(tid)
            continue

        if tool in ("Task", "Agent") and ev in ("PostToolUse", "PostToolUseFailure"):
            d = dispatches.get(e.get("tool_use_id"))
            if d is None:  # Pre event missed — create from Post
                tid = e.get("tool_use_id") or f"anon-{len(order)}"
                start = e["ts"] - (e.get("duration_ms") or 0) / 1000
                d = dispatches[tid] = {
                    "id": tid, "agent": (e.get("subagent_type") or "unknown").lower(),
                    "description": e.get("description") or "",
                    "task": task_key(e.get("description")), "start": start,
                    "project": e.get("project") or "",
                }
                order.append(tid)
            d["end"] = e["ts"]
            text = e.get("result_text") or ""
            if ev == "PostToolUseFailure":
                d["status"] = "ERROR"
            elif d["agent"] == "worker":
                m = STATUS_RE.search(text)
                d["status"] = m.group(1).upper() if m else "NO_REPORT"
                a = ATTEMPTS_RE.search(text)
                d["attempts"] = int(a.group(1)) if a else None
            elif d["agent"] == "advisor":
                m = CONF_RE.search(text)
                d["status"] = "GUIDANCE"
                d["confidence"] = m.group(1).lower() if m else None
            else:
                d["status"] = "DONE"
            if e.get("tokens"):
                d["tokens"] = e["tokens"]
                tokens_by_agent[d["agent"]] += e["tokens"]
            if e.get("duration_ms"):
                d["start"] = min(d["start"], d["end"] - e["duration_ms"] / 1000)
            continue

        if ev in ("PostToolUse", "PostToolUseFailure") and tool:
            who = (e.get("agent_type") or "orchestrator").lower()
            tool_calls[who] += 1
            if ev == "PostToolUseFailure":
                tool_fail[who] += 1

        if ev == "SubagentStop" and e.get("tokens_detail"):
            who = (e.get("agent_type") or "unknown").lower()
            td = e["tokens_detail"]
            # only use transcript tokens if the Task response had none
            if not any(dispatches[i].get("tokens") for i in order if dispatches[i]["agent"] == who):
                tokens_by_agent[who] += td.get("input", 0) + td.get("output", 0)

        if tool == "TodoWrite" and e.get("todos") is not None:
            plan = {f"todo-{i}": {"subject": t.get("content"), "status": t.get("status")}
                    for i, t in enumerate(e["todos"])}
        if tool in ("TaskCreate", "TaskUpdate") and e.get("task"):
            t = e["task"]
            key = t.get("taskId") or t.get("subject")
            if key:
                cur = plan.setdefault(str(key), {"subject": None, "status": "pending"})
                if t.get("subject"):
                    cur["subject"] = t["subject"]
                if t.get("status"):
                    cur["status"] = t["status"]

    ds = [dispatches[i] for i in order]
    for d in ds:
        d["duration"] = ((d["end"] or now) - d["start"])

    # ---- per-task lifecycle -------------------------------------------
    tasks = {}
    for d in ds:
        key = f'{d["project"]}/{d["task"]}'
        t = tasks.setdefault(key, {
            "task": d["task"], "project": d["project"], "title": d["description"], "worker_runs": 0,
            "advisor_rounds": 0, "first_try": None, "state": "queued",
            "start": d["start"], "end": None, "history": [],
        })
        t["history"].append({"agent": d["agent"], "status": d["status"]})
        if d["agent"] == "worker":
            t["worker_runs"] += 1
            t["title"] = d["description"] or t["title"]
            if t["first_try"] is None and d["status"] != "RUNNING":
                t["first_try"] = d["status"] == "WORKS"
            if d["status"] == "RUNNING":
                t["state"] = "in_progress"
            elif d["status"] == "WORKS":
                t["state"], t["end"] = "done", d["end"]
            else:
                t["state"] = "stuck" if t["advisor_rounds"] >= MAX_ADVISOR_ROUNDS else "failing"
        elif d["agent"] == "advisor":
            t["advisor_rounds"] += 1
            t["state"] = "consulting" if d["status"] == "RUNNING" else "retry_pending"

    tlist = sorted(tasks.values(), key=lambda t: t["start"])
    for t in tlist:
        t["key"] = f'{t["project"]}/{t["task"]}' 
    for t in tlist:
        t["fixed_after_advice"] = t["state"] == "done" and t["advisor_rounds"] > 0

    # ---- per-agent workload & performance ------------------------------
    agents = {}
    names = ["orchestrator", "worker", "advisor"] + sorted(
        {d["agent"] for d in ds} - {"worker", "advisor", "orchestrator"})
    for a in names:
        mine = [d for d in ds if d["agent"] == a]
        done = [d for d in mine if d["status"] != "RUNNING"]
        durs = sorted(d["duration"] for d in done)
        agents[a] = {
            "running": sum(1 for d in mine if d["status"] == "RUNNING"),
            "dispatches": len(mine),
            "completed": len(done),
            "busy_sec": round(sum(d["duration"] for d in mine), 1),
            "avg_sec": round(sum(durs) / len(durs), 1) if durs else None,
            "p90_sec": round(durs[int(0.9 * (len(durs) - 1))], 1) if durs else None,
            "tool_calls": tool_calls.get(a, 0),
            "tool_failures": tool_fail.get(a, 0),
            "tokens": tokens_by_agent.get(a, 0),
        }
    w = [d for d in ds if d["agent"] == "worker" and d["status"] != "RUNNING"]
    agents["worker"]["works"] = sum(1 for d in w if d["status"] == "WORKS")
    agents["worker"]["fails"] = len(w) - agents["worker"]["works"]

    finished_tasks = [t for t in tlist if t["first_try"] is not None]
    escalated = [t for t in tlist if t["advisor_rounds"] > 0]
    pct = lambda n, d: round(100 * n / d, 1) if d else None

    counts = defaultdict(int)
    for t in tlist:
        counts[t["state"]] += 1
    planned_total = len(plan)
    planned_done = sum(1 for p in plan.values() if (p.get("status") or "").lower() in ("completed", "done"))

    first_ts = events[0]["ts"] if events else now
    perf = {
        "first_try_success_pct": pct(sum(1 for t in finished_tasks if t["first_try"]), len(finished_tasks)),
        "escalation_pct": pct(len(escalated), len(tlist)),
        "advisor_fix_pct": pct(sum(1 for t in escalated if t["state"] == "done"), len(escalated)),
        "worker_success_pct": pct(agents["worker"]["works"], len(w)),
        "avg_task_sec": (lambda xs: round(sum(xs) / len(xs), 1) if xs else None)(
            [t["end"] - t["start"] for t in tlist if t["end"]]),
        "throughput_per_hour": round(counts["done"] / max((now - first_ts) / 3600, 1 / 60), 2),
        "total_tokens": sum(tokens_by_agent.values()),
        "cost_usd": round(sum(r.get("cost_usd") or 0 for r in runs), 4),
    }

    return {
        "generated_at": now,
        "since": first_ts,
        "sessions": len(sessions),
        "progress": {
            "tasks_total": len(tlist),
            "by_state": dict(counts),
            "planned_total": planned_total,
            "planned_done": planned_done,
            "pct": pct(planned_done, planned_total) if planned_total else pct(counts["done"], len(tlist)),
        },
        "agents": agents,
        "performance": perf,
        "tasks": tlist,
        "plan": list(plan.values()),
        "timeline": [{k: d.get(k) for k in ("agent", "task", "project", "status", "start", "end", "description")} for d in ds],
        "runs": runs[-20:],
    }


def list_projects(path):
    names = set()
    for e in load_events(path):
        if e.get("project"):
            names.add(e["project"])
    return sorted(names)


class Handler(BaseHTTPRequestHandler):
    log_path = DEFAULT_LOG

    def _send(self, code, body, ctype):
        data = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path.startswith("/api/state"):
            from urllib.parse import urlparse, parse_qs
            q = parse_qs(urlparse(self.path).query)
            proj = (q.get("project") or [None])[0]
            state = compute(load_events(self.log_path, proj))
            state["projects"] = list_projects(self.log_path)
            self._send(200, json.dumps(state, ensure_ascii=False), "application/json; charset=utf-8")
        elif self.path in ("/", "/index.html"):
            with open(os.path.join(HERE, "index.html"), "rb") as f:
                self._send(200, f.read(), "text/html; charset=utf-8")
        else:
            self._send(404, "not found", "text/plain")

    def log_message(self, *args):
        pass


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--port", type=int, default=8765)
    p.add_argument("--host", default="127.0.0.1")
    p.add_argument("--log", default=os.environ.get("AGENT_DASHBOARD_LOG", DEFAULT_LOG))
    p.add_argument("--json", action="store_true", help="print metrics once and exit")
    p.add_argument("--project", default=None, help="only this project (folder name)")
    a = p.parse_args()
    if a.json:
        print(json.dumps(compute(load_events(a.log, a.project)), ensure_ascii=False, indent=2))
        return
    Handler.log_path = a.log
    print(f"Dashboard: http://{a.host}:{a.port}   (log: {a.log})")
    ThreadingHTTPServer((a.host, a.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
