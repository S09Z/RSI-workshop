#!/usr/bin/env python3
"""Claude Code hook: append one compact event to ~/.claude/agent-dashboard/events.jsonl.

Global hook (lives in ~/.claude). It is a no-op unless the session was started
through `orch`, `orch-headless` or with AGENT_WORKFLOW=1, so ordinary Claude
Code sessions in other projects are not logged.

Never blocks or fails a session: any error is swallowed and the script exits 0.
"""
import json
import os
import sys
import time

MAX_TEXT = 4000


def _text(v):
    if v is None:
        return ""
    if isinstance(v, str):
        return v
    if isinstance(v, list):
        return "\n".join(_text(x) for x in v)
    if isinstance(v, dict):
        for k in ("text", "content", "result", "output", "last_assistant_message"):
            if k in v:
                return _text(v[k])
        return json.dumps(v, ensure_ascii=False)
    return str(v)


def _num(d, *keys):
    if not isinstance(d, dict):
        return None
    for k in keys:
        v = d.get(k)
        if isinstance(v, (int, float)):
            return v
    return None


def _transcript_tokens(path):
    if not path or not os.path.exists(path):
        return None
    total = {"input": 0, "output": 0, "cache_read": 0}
    try:
        with open(path, encoding="utf-8") as f:
            for line in f:
                try:
                    u = json.loads(line).get("message", {}).get("usage") or {}
                except Exception:
                    continue
                total["input"] += u.get("input_tokens", 0) or 0
                total["output"] += u.get("output_tokens", 0) or 0
                total["cache_read"] += u.get("cache_read_input_tokens", 0) or 0
    except Exception:
        return None
    return total if any(total.values()) else None


def log_dir():
    base = os.environ.get("AGENT_DASHBOARD_DIR") or os.path.join(
        os.path.expanduser("~"), ".claude", "agent-dashboard")
    return base


def main():
    if not (os.environ.get("AGENT_WORKFLOW") == "1"):
        return
    raw = sys.stdin.read()
    data = json.loads(raw) if raw.strip() else {}
    ev = data.get("hook_event_name", "unknown")
    tool = data.get("tool_name")
    cwd = data.get("cwd") or os.getcwd()
    out = {
        "ts": time.time(),
        "event": ev,
        "project": os.path.basename(cwd.rstrip("/")) or cwd,
        "cwd": cwd,
        "session_id": data.get("session_id"),
        "agent_id": data.get("agent_id"),
        "agent_type": data.get("agent_type"),
    }

    if tool:
        out["tool"] = tool
        out["tool_use_id"] = data.get("tool_use_id")

    ti = data.get("tool_input") or {}

    if tool in ("Task", "Agent"):
        out["subagent_type"] = ti.get("subagent_type")
        out["description"] = ti.get("description")
        if ev == "PostToolUse":
            resp = data.get("tool_response")
            out["result_text"] = _text(resp)[-MAX_TEXT:]
            out["duration_ms"] = _num(resp, "totalDurationMs", "duration_ms")
            out["tokens"] = _num(resp, "totalTokens", "total_tokens")
            out["tool_uses"] = _num(resp, "totalToolUseCount")

    elif tool == "TodoWrite":
        out["todos"] = [
            {"content": t.get("content"), "status": t.get("status")}
            for t in ti.get("todos", [])
        ]
    elif tool in ("TaskCreate", "TaskUpdate"):
        out["task"] = {k: ti.get(k) for k in ("taskId", "subject", "status") if k in ti}
        resp = data.get("tool_response")
        if isinstance(resp, dict):
            tid = resp.get("taskId") or resp.get("id") or (resp.get("task") or {}).get("id")
            if tid:
                out["task"]["taskId"] = str(tid)

    if ev in ("SubagentStop", "Stop"):
        out["result_text"] = _text(data.get("last_assistant_message"))[-MAX_TEXT:]
        out["tokens_detail"] = _transcript_tokens(
            data.get("agent_transcript_path")
            or (data.get("transcript_path") if ev == "SubagentStop" else None)
        )

    if ev in ("TaskCreated", "TaskCompleted"):
        out["task"] = {
            k: data.get(k)
            for k in ("task_id", "task_subject", "subject", "status")
            if data.get(k) is not None
        }

    d = log_dir()
    os.makedirs(d, exist_ok=True)
    with open(os.path.join(d, "events.jsonl"), "a", encoding="utf-8") as f:
        f.write(json.dumps(out, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
    sys.exit(0)
