# Orchestrator · Worker · Advisor — global setup

ติดตั้งครั้งเดียวต่อเครื่อง ใช้ได้กับทุกโปรเจกต์ ไม่มีไฟล์ไหนถูกเขียนลงใน repo

## ติดตั้ง
```bash
./install.sh
export PATH="$HOME/.local/bin:$PATH"   # ถ้ายังไม่มี
```

สิ่งที่ติดตั้งไปที่เครื่อง:
| ที่อยู่ | เนื้อหา |
|---|---|
| `~/.claude/agents/orchestrator.md` | Orchestrator (รันเป็น main session ด้วย `--agent`) |
| `~/.claude/agents/worker.md` | Worker subagent |
| `~/.claude/agents/advisor.md` | Advisor subagent (`memory: user`) |
| `~/.claude/hooks/log_event.py` | hook เก็บ event ให้ dashboard (ทำงานเฉพาะเมื่อ `AGENT_WORKFLOW=1`) |
| `~/.claude/settings.json` | เพิ่ม hook entries (ไม่แตะค่าอื่น, สำรองไฟล์เดิมเป็น `.bak-<time>`) |
| `~/.claude/agent-memory/advisor/` | memory ของ Advisor ทุกโปรเจกต์ (สร้างโดย Advisor เอง) |
| `~/.claude/agent-dashboard/` | ไฟล์ log และ dashboard |
| `~/.local/bin/orch`, `orch-headless`, `orch-dashboard` | คำสั่งที่ใช้งาน |

ติดตั้งซ้ำได้ปลอดภัย ถอนการติดตั้งด้วย `./install.sh --uninstall`

## ใช้งาน
```bash
cd ~/code/my-app
orch                          # เปิด session แบบ interactive โดย main session เป็น Orchestrator
orch-headless "Fix the failing checkout tests"   # รันเบื้องหลัง บันทึก cost ให้ dashboard
orch-dashboard                # http://127.0.0.1:8765  (เลือกโปรเจกต์จาก dropdown ได้)
orch-dashboard --project my-app
```

## ทำงานอย่างไร
- `orch` ตั้ง `AGENT_WORKFLOW=1` แล้วเรียก `claude --agent orchestrator` ใน `--agent` mode subagent ถูกจำกัดให้เรียกได้เฉพาะ `Agent(worker, advisor)` ตาม frontmatter
- Worker และ Advisor เป็น subagent ที่ Orchestrator เรียกผ่าน Agent tool, Advisor เก็บ memory ที่ `~/.claude/agent-memory/advisor/` แยกไฟล์ตามโปรเจกต์ (`projects/<project>.md`) และใช้ `topics/` สำหรับความรู้ข้ามโปรเจกต์
- hook บันทึกทุก dispatch พร้อมชื่อโปรเจกต์ (ชื่อโฟลเดอร์) และ dashboard รวมทุกโปรเจกต์ไว้ที่เดียว

## ข้อควรระวัง
- Plugin subagent ไม่รองรับ `hooks`, `permissionMode`, `mcpServers` จึงใช้วิธีวางไฟล์ไว้ใน `~/.claude/agents/` แทน
- `memory` ของ subagent ต้องมี Read/Write/Edit (ตั้งไว้ใน advisor.md แล้ว) ถ้าไม่เกิดไฟล์ `MEMORY.md` ให้ตรวจสอบหลังใช้งานครั้งแรก
- ค่า token ของ subagent ขึ้นกับว่า hook ได้รับข้อมูลหรือไม่ ควรตรวจในการรันจริงครั้งแรก
- Advisor เขียนได้เฉพาะโฟลเดอร์ memory ของตัวเอง แต่ `Bash` ยังสั่งคำสั่งอะไรก็ได้ตามสิทธิ์ของ session ควรใช้กับโปรเจกต์ที่ไว้ใจได้
